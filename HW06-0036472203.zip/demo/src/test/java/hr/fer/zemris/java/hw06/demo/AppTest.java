package hr.fer.zemris.java.hw06.demo;

import org.junit.Test;
import org.junit.Assert;

public class AppTest
{
    @Test
    public void testApp()
    {
        Assert.assertTrue( true );
    }
}
